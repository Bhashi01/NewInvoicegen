# B2I Invoice Generator 📄

A Flask web app that reads trainer CSV data and generates professional PDF invoices — all billed to **Metis Eduventures Private Limited**.

## Features
- Upload B2I Sourcing Master CSV
- Dashboard with trainer overview, search, and stats
- Generate individual PDF invoices per trainer
- Batch-generate all invoices as a single ZIP download
- Summary report PDF with totals
- Constant buyer (Metis Eduventures) on every invoice

---

## 🖥️ Run Locally

```bash
# 1. Clone / download the project
cd invoice-app

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate        # Linux/Mac
# venv\Scripts\activate          # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run
python app.py
```
Open **http://localhost:5000** in your browser.

---

## 🚀 Deployment Options

### Option 1: Railway (Recommended — Free Tier)

1. **Create account** at [railway.app](https://railway.app)
2. Push this code to a **GitHub repo**
3. In Railway dashboard → **New Project → Deploy from GitHub repo**
4. Railway auto-detects the `Procfile` and deploys
5. Click **Add a Domain** to get your public URL

```bash
# Or use Railway CLI
npm install -g @railway/cli
railway login
railway init
railway up
```

### Option 2: Render (Free Tier)

1. **Create account** at [render.com](https://render.com)
2. Push code to **GitHub**
3. New → **Web Service** → Connect your repo
4. Render auto-detects `render.yaml` config
5. Your app will be live at `your-app.onrender.com`

### Option 3: PythonAnywhere (Free Tier)

1. **Sign up** at [pythonanywhere.com](https://www.pythonanywhere.com)
2. Go to **Web** tab → Add a new web app → Flask
3. Upload files via **Files** tab or use `git clone` in Bash console
4. In the Bash console:
   ```bash
   cd ~/invoice-app
   pip install -r requirements.txt
   ```
5. In **Web** tab, set:
   - **Source code:** `/home/yourusername/invoice-app`
   - **WSGI file:** edit to point to your app:
     ```python
     import sys
     sys.path.insert(0, '/home/yourusername/invoice-app')
     from app import app as application
     ```
6. Click **Reload** — your app is live!

### Option 4: Docker (Any Cloud / VPS)

```bash
# Build
docker build -t b2i-invoices .

# Run
docker run -p 8080:8080 b2i-invoices
```

Deploy the Docker image to: **Google Cloud Run** (free tier), **AWS App Runner**, **DigitalOcean App Platform**, **Fly.io**, or any VPS.

### Option 5: Google Cloud Run (Free Tier)

```bash
# Install gcloud CLI, then:
gcloud init
gcloud run deploy b2i-invoices \
  --source . \
  --region asia-south1 \
  --allow-unauthenticated
```

---

## 📁 Project Structure

```
invoice-app/
├── app.py                 # Flask web application
├── invoice_pdf.py         # PDF generation engine
├── templates/
│   ├── index.html         # Upload page
│   └── dashboard.html     # Trainer dashboard
├── uploads/               # Uploaded CSVs (gitignored)
├── generated/             # Generated PDFs (gitignored)
├── requirements.txt       # Python dependencies
├── Procfile               # Railway / Heroku
├── Dockerfile             # Docker / Cloud Run
├── render.yaml            # Render.com config
└── README.md              # This file
```

---

## 🔧 Environment Variables

| Variable     | Default                    | Description          |
|-------------|----------------------------|----------------------|
| `SECRET_KEY` | `b2i-invoice-secret-...`  | Flask session secret |
| `PORT`       | `5000`                     | Server port          |

---

## 📄 CSV Format Expected

Your CSV should have these columns:
- `Name` — Trainer name
- `Email ID` — Trainer email
- `Number` — Phone number
- `Program Name` — e.g., Aptitude, FSD
- `College Name` — e.g., GPREC, MSRUAS
- `Start Date`, `End Date` — Training dates
- `Commercials` — Rate per day
- `Total Days /Month` — Number of days worked
- `Total Cost Commercials & Reimbusement` — Total amount
- `Reimbusement` — Reimbursement amount (if any)
