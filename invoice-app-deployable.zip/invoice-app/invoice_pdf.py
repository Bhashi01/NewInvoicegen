"""
PDF Invoice Generator Module
Generates professional PDF invoices using ReportLab.
"""

from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor
from reportlab.pdfgen import canvas
from reportlab.platypus import Table, TableStyle


BUYER = {
    "name": "Metis Eduventures Private Limited",
    "address_line1": "2nd Floor, 207A-208, Tower A, Unitech Cyber Park,",
    "address_line2": "Sec-39, Gurgaon, Haryana - 122001",
    "gstin": "06AAHCM7263M1ZZ",
}

COLORS = {
    "primary":    HexColor("#0f2b46"),
    "accent":     HexColor("#d4870e"),
    "accent2":    HexColor("#f0a830"),
    "bg_light":   HexColor("#f7f5f0"),
    "bg_warm":    HexColor("#fdf8f0"),
    "text_dark":  HexColor("#1a1a1a"),
    "text_muted": HexColor("#6b7280"),
    "border":     HexColor("#e0dcd4"),
    "white":      HexColor("#ffffff"),
    "footer_txt": HexColor("#94a3b8"),
}


def fmt(amount):
    return f"\u20b9{amount:,.2f}"


def generate_trainer_invoice(trainer, inv_number, output_path):
    w, h = A4
    c = canvas.Canvas(output_path, pagesize=A4)
    cl = COLORS

    # Header
    c.setFillColor(cl["primary"])
    c.rect(0, h - 108, w, 108, fill=1, stroke=0)
    c.setFillColor(cl["accent"])
    c.rect(0, h - 112, w, 4, fill=1, stroke=0)

    c.setFillColor(cl["white"])
    c.setFont("Helvetica-Bold", 32)
    c.drawString(40, h - 50, "INVOICE")
    c.setFont("Helvetica", 10)
    c.setFillColor(cl["accent2"])
    c.drawString(40, h - 68, f"#{inv_number}")

    c.setFont("Helvetica", 9)
    c.setFillColor(HexColor("#8faabe"))
    c.drawString(40, h - 86, f"From: {trainer['name']}")
    email = trainer.get("email", "")
    if email and email != "nan":
        c.drawString(40, h - 99, email)

    c.setFillColor(cl["white"])
    c.setFont("Helvetica", 10)
    c.drawRightString(w - 40, h - 50, f"Date: {datetime.now().strftime('%d-%b-%Y')}")
    c.setFont("Helvetica", 9)
    c.setFillColor(HexColor("#8faabe"))
    c.drawRightString(w - 40, h - 66, f"Trainer ID: B2I-{inv_number[-3:]}")

    y = h - 140

    # Billed To
    c.setFillColor(cl["bg_warm"])
    c.roundRect(40, y - 80, w - 80, 80, 8, fill=1, stroke=0)
    c.setFillColor(cl["accent"])
    c.rect(40, y - 80, 5, 80, fill=1, stroke=0)

    c.setFont("Helvetica-Bold", 8)
    c.setFillColor(cl["accent"])
    c.drawString(56, y - 14, "BILLED TO")
    c.setFont("Helvetica-Bold", 12)
    c.setFillColor(cl["text_dark"])
    c.drawString(56, y - 30, BUYER["name"])
    c.setFont("Helvetica", 9)
    c.setFillColor(cl["text_muted"])
    c.drawString(56, y - 44, BUYER["address_line1"])
    c.drawString(56, y - 57, BUYER["address_line2"])
    c.setFont("Helvetica-Bold", 9)
    c.setFillColor(cl["primary"])
    c.drawString(56, y - 72, f"GSTIN: {BUYER['gstin']}")

    # From
    rx = w - 230
    c.setFont("Helvetica-Bold", 8)
    c.setFillColor(cl["accent"])
    c.drawString(rx, y - 14, "FROM")
    c.setFont("Helvetica-Bold", 11)
    c.setFillColor(cl["text_dark"])
    c.drawString(rx, y - 30, trainer["name"][:35])
    c.setFont("Helvetica", 9)
    c.setFillColor(cl["text_muted"])
    dy = y - 44
    if email and email != "nan":
        c.drawString(rx, dy, email)
        dy -= 13
    phone = trainer.get("phone", "")
    if phone and phone != "nan":
        c.drawString(rx, dy, f"Ph: {phone}")

    y -= 100

    # Items table
    header = ["#", "Description", "Days", "Rate/Day", "Amount"]
    rows = [header]
    for idx, item in enumerate(trainer["items"]):
        desc = item["description"]
        if len(desc) > 55:
            desc = desc[:52] + "..."
        rows.append([
            str(idx + 1), desc, f"{item['days']:.0f}",
            fmt(item['rate_per_day']), fmt(item['training_cost']),
        ])

    total_reimb = trainer.get("total_reimb", 0)
    if total_reimb > 0:
        rows.append(["", "Reimbursement (Travel/Food/Accommodation)", "", "", fmt(total_reimb)])

    col_widths = [28, 235, 40, 85, 95]
    avail = w - 80
    col_widths[1] = avail - sum(col_widths) + col_widths[1]

    t = Table(rows, colWidths=col_widths)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), cl["primary"]),
        ("TEXTCOLOR", (0, 0), (-1, 0), cl["white"]),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 8),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 1), (-1, -1), 8.5),
        ("TEXTCOLOR", (0, 1), (-1, -1), cl["text_dark"]),
        ("ALIGN", (0, 0), (0, -1), "CENTER"),
        ("ALIGN", (2, 0), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [cl["white"], cl["bg_light"]]),
        ("LINEBELOW", (0, 0), (-1, 0), 1.5, cl["accent"]),
        ("LINEBELOW", (0, -1), (-1, -1), 0.5, cl["border"]),
    ]))

    tw, th = t.wrap(0, 0)
    if y - th < 160:
        c.showPage()
        y = h - 60
    t.drawOn(c, 40, y - th)
    y -= (th + 24)

    # Totals
    tx = w - 260
    box_h = 90 if total_reimb > 0 else 75
    c.setFillColor(cl["bg_warm"])
    c.roundRect(tx - 12, y - box_h, 242, box_h, 8, fill=1, stroke=0)

    c.setFont("Helvetica", 10)
    c.setFillColor(cl["text_muted"])
    ty = y - 18
    c.drawString(tx, ty, "Training Cost")
    c.drawRightString(w - 40, ty, fmt(trainer.get("total_training", 0)))
    ty -= 20

    if total_reimb > 0:
        c.drawString(tx, ty, "Reimbursement")
        c.drawRightString(w - 40, ty, fmt(total_reimb))
        ty -= 20

    c.setStrokeColor(cl["accent"])
    c.setLineWidth(2)
    c.line(tx, ty - 2, w - 40, ty - 2)

    c.setFont("Helvetica-Bold", 16)
    c.setFillColor(cl["primary"])
    ty -= 22
    c.drawString(tx, ty, "Total Payable")
    c.drawRightString(w - 40, ty, fmt(trainer.get("grand_total", 0)))

    # Footer
    c.setFillColor(cl["primary"])
    c.rect(0, 0, w, 32, fill=1, stroke=0)
    c.setFillColor(cl["accent"])
    c.rect(0, 32, w, 2, fill=1, stroke=0)
    c.setFillColor(cl["footer_txt"])
    c.setFont("Helvetica", 7.5)
    c.drawCentredString(w / 2, 12, "B2I Sourcing  |  Invoice for Metis Eduventures Pvt. Ltd.  |  Thank you!")

    c.save()
    return output_path


def generate_summary_pdf(trainers, output_path):
    w, h = A4
    c = canvas.Canvas(output_path, pagesize=A4)
    cl = COLORS

    c.setFillColor(cl["primary"])
    c.rect(0, h - 90, w, 90, fill=1, stroke=0)
    c.setFillColor(cl["accent"])
    c.rect(0, h - 93, w, 3, fill=1, stroke=0)

    c.setFillColor(cl["white"])
    c.setFont("Helvetica-Bold", 24)
    c.drawString(40, h - 48, "INVOICE SUMMARY REPORT")
    c.setFont("Helvetica", 10)
    c.setFillColor(cl["accent2"])
    c.drawString(40, h - 66, f"Generated: {datetime.now().strftime('%d-%b-%Y %H:%M')}")
    c.setFillColor(HexColor("#8faabe"))
    c.drawString(40, h - 80, f"Billed To: {BUYER['name']}")

    y = h - 115

    grand_total = sum(t["grand_total"] for t in trainers.values())
    grand_days = sum(t["total_days"] for t in trainers.values())

    c.setFillColor(cl["bg_warm"])
    c.roundRect(40, y - 40, w - 80, 40, 8, fill=1, stroke=0)
    c.setFont("Helvetica-Bold", 11)
    c.setFillColor(cl["primary"])
    c.drawString(55, y - 15, f"Trainers: {len(trainers)}")
    c.drawString(190, y - 15, f"Days: {grand_days:.0f}")
    c.drawString(310, y - 15, f"Grand Total: {fmt(grand_total)}")
    c.setFont("Helvetica", 9)
    c.setFillColor(cl["text_muted"])
    c.drawString(55, y - 32, f"GSTIN: {BUYER['gstin']}")

    y -= 58

    sorted_t = sorted(trainers.values(), key=lambda x: x["grand_total"], reverse=True)
    header = ["#", "Trainer Name", "Days", "Training", "Reimb.", "Total"]
    rows = [header]
    for i, t in enumerate(sorted_t):
        rows.append([
            str(i + 1), t["name"][:32], f"{t['total_days']:.0f}",
            fmt(t["total_training"]),
            fmt(t["total_reimb"]) if t["total_reimb"] > 0 else "—",
            fmt(t["grand_total"]),
        ])

    col_w = [28, 180, 40, 95, 70, 95]
    page_sz = 35

    for ps in range(0, len(rows) - 1, page_sz):
        if ps > 0:
            c.showPage()
            y = h - 50
            c.setFont("Helvetica-Bold", 12)
            c.setFillColor(cl["primary"])
            c.drawString(40, y, "INVOICE SUMMARY (continued)")
            y -= 25

        pr = [header] + rows[ps + 1: ps + 1 + page_sz]
        t = Table(pr, colWidths=col_w)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), cl["primary"]),
            ("TEXTCOLOR", (0, 0), (-1, 0), cl["white"]),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, 0), 8),
            ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
            ("FONTSIZE", (0, 1), (-1, -1), 8),
            ("TEXTCOLOR", (0, 1), (-1, -1), cl["text_dark"]),
            ("ALIGN", (0, 0), (0, -1), "CENTER"),
            ("ALIGN", (2, 0), (-1, -1), "RIGHT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [cl["white"], cl["bg_light"]]),
            ("LINEBELOW", (0, 0), (-1, 0), 1.5, cl["accent"]),
        ]))
        tw, th = t.wrap(0, 0)
        t.drawOn(c, 40, y - th)

    c.setFillColor(cl["primary"])
    c.rect(0, 0, w, 28, fill=1, stroke=0)
    c.setFillColor(cl["accent"])
    c.rect(0, 28, w, 2, fill=1, stroke=0)
    c.setFillColor(cl["footer_txt"])
    c.setFont("Helvetica", 7)
    c.drawCentredString(w / 2, 9, "B2I Sourcing Master — Confidential Invoice Summary")
    c.save()
    return output_path
