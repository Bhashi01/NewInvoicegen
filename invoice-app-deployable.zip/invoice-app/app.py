"""
B2I Invoice Generator — Flask Web Application
Upload CSV → Preview trainers → Generate & download PDF invoices
Billed To: Metis Eduventures Private Limited (constant)
"""

import os
import re
import json
import zipfile
import shutil
from datetime import datetime
from io import BytesIO

import pandas as pd
from flask import (
    Flask, render_template, request, redirect, url_for,
    send_file, flash, jsonify, session
)
from werkzeug.utils import secure_filename

from invoice_pdf import generate_trainer_invoice, generate_summary_pdf, BUYER

# ── App Config ──
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "b2i-invoice-secret-key-change-in-production")
app.config["UPLOAD_FOLDER"] = os.path.join(os.path.dirname(__file__), "uploads")
app.config["OUTPUT_FOLDER"] = os.path.join(os.path.dirname(__file__), "generated")
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16MB max

os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
os.makedirs(app.config["OUTPUT_FOLDER"], exist_ok=True)

ALLOWED_EXTENSIONS = {"csv"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


# ── Data Processing ──
def parse_num(val):
    if pd.isna(val):
        return 0.0
    s = str(val).replace(",", "").replace('"', "").replace("₹", "").strip()
    try:
        return float(s)
    except ValueError:
        return 0.0


def clean_name(name):
    return re.sub(r'[^\w\s-]', '', str(name)).strip().replace(' ', '_')


def process_csv(filepath):
    """Load CSV and return trainer data grouped by name."""
    df = pd.read_csv(filepath)
    df = df.dropna(subset=["Name"])
    df = df[df["Name"].str.strip() != ""]

    df["comm_clean"] = df["Commercials"].apply(parse_num)
    df["days_clean"] = df["Total Days /Month"].apply(parse_num)
    df["total_cost_clean"] = df["Total Cost Commercials & Reimbusement"].apply(parse_num)
    df["reimb_clean"] = df["Reimbusement"].apply(parse_num)

    trainers = {}
    for name, group in df.groupby("Name"):
        name = name.strip()
        first_row = group.iloc[0]
        items = []

        for _, row in group.iterrows():
            program = str(row.get("Program Name", "Training")).strip()
            college = str(row.get("College Name", "")).strip()
            start = str(row.get("Start Date", "")).strip()
            end = str(row.get("End Date", "")).strip()
            days = parse_num(row.get("Total Days /Month", 0))
            rate = parse_num(row.get("Commercials", 0))
            total_cost = parse_num(row.get("Total Cost Commercials & Reimbusement", 0))
            reimb = parse_num(row.get("Reimbusement", 0))

            desc = f"{program} Training"
            if college and college != "nan":
                desc += f" @ {college}"
            if start and start != "nan" and end and end != "nan":
                desc += f" ({start} to {end})"

            amount = total_cost if total_cost > 0 else days * rate
            training_cost = amount - reimb if reimb > 0 else amount

            items.append({
                "description": desc,
                "days": days,
                "rate_per_day": rate,
                "training_cost": training_cost,
                "reimbursement": reimb,
                "total": amount,
            })

        trainers[name] = {
            "name": name,
            "email": str(first_row.get("Email ID", "")).strip(),
            "phone": str(first_row.get("Number", "")).strip(),
            "items": items,
            "total_days": sum(i["days"] for i in items),
            "total_training": sum(i["training_cost"] for i in items),
            "total_reimb": sum(i["reimbursement"] for i in items),
            "grand_total": sum(i["total"] for i in items),
        }

    return trainers


# ── Routes ──

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/upload", methods=["POST"])
def upload():
    if "file" not in request.files:
        flash("No file selected", "error")
        return redirect(url_for("index"))

    file = request.files["file"]
    if file.filename == "":
        flash("No file selected", "error")
        return redirect(url_for("index"))

    if not allowed_file(file.filename):
        flash("Only CSV files are allowed", "error")
        return redirect(url_for("index"))

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(filepath)

    try:
        trainers = process_csv(filepath)
        # Store trainer data in session-accessible JSON
        data_path = os.path.join(app.config["UPLOAD_FOLDER"], "trainer_data.json")
        # Convert to serializable format
        serializable = {}
        for k, v in trainers.items():
            serializable[k] = v
        with open(data_path, "w") as f:
            json.dump(serializable, f)

        session["csv_uploaded"] = True
        session["csv_filename"] = filename
        flash(f"Loaded {len(trainers)} trainers successfully!", "success")
        return redirect(url_for("dashboard"))

    except Exception as e:
        flash(f"Error processing CSV: {str(e)}", "error")
        return redirect(url_for("index"))


@app.route("/dashboard")
def dashboard():
    data_path = os.path.join(app.config["UPLOAD_FOLDER"], "trainer_data.json")
    if not os.path.exists(data_path):
        flash("Please upload a CSV first", "error")
        return redirect(url_for("index"))

    with open(data_path) as f:
        trainers = json.load(f)

    # Sort by grand total descending
    sorted_trainers = sorted(trainers.values(), key=lambda x: x["grand_total"], reverse=True)

    stats = {
        "total_trainers": len(trainers),
        "total_days": sum(t["total_days"] for t in trainers.values()),
        "grand_total": sum(t["grand_total"] for t in trainers.values()),
        "total_reimb": sum(t["total_reimb"] for t in trainers.values()),
    }

    return render_template("dashboard.html", trainers=sorted_trainers, stats=stats, buyer=BUYER)


@app.route("/generate/<trainer_name>")
def generate_single(trainer_name):
    data_path = os.path.join(app.config["UPLOAD_FOLDER"], "trainer_data.json")
    with open(data_path) as f:
        trainers = json.load(f)

    if trainer_name not in trainers:
        flash("Trainer not found", "error")
        return redirect(url_for("dashboard"))

    trainer = trainers[trainer_name]
    safe = clean_name(trainer_name)
    inv_num = f"B2I-{datetime.now().strftime('%Y')}-{abs(hash(trainer_name)) % 999:03d}"
    filename = f"{inv_num}_{safe}.pdf"
    filepath = os.path.join(app.config["OUTPUT_FOLDER"], filename)

    generate_trainer_invoice(trainer, inv_num, filepath)

    return send_file(filepath, as_attachment=True, download_name=filename)


@app.route("/generate-all", methods=["POST"])
def generate_all():
    data_path = os.path.join(app.config["UPLOAD_FOLDER"], "trainer_data.json")
    with open(data_path) as f:
        trainers = json.load(f)

    # Clean old generated files
    out_dir = app.config["OUTPUT_FOLDER"]
    for f_name in os.listdir(out_dir):
        os.remove(os.path.join(out_dir, f_name))

    # Generate all invoices
    generated = []
    for idx, (name, trainer) in enumerate(sorted(trainers.items()), 1):
        inv_num = f"B2I-{datetime.now().strftime('%Y')}-{idx:03d}"
        safe = clean_name(name)
        filename = f"{inv_num}_{safe}.pdf"
        filepath = os.path.join(out_dir, filename)
        generate_trainer_invoice(trainer, inv_num, filepath)
        generated.append(filename)

    # Generate summary
    summary_path = os.path.join(out_dir, "00_Summary_Report.pdf")
    generate_summary_pdf(trainers, summary_path)
    generated.append("00_Summary_Report.pdf")

    # Create ZIP
    zip_path = os.path.join(out_dir, "all_invoices.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for fname in generated:
            fpath = os.path.join(out_dir, fname)
            zf.write(fpath, fname)

    return send_file(zip_path, as_attachment=True, download_name="B2I_All_Invoices.zip")


@app.route("/generate-summary")
def generate_summary():
    data_path = os.path.join(app.config["UPLOAD_FOLDER"], "trainer_data.json")
    with open(data_path) as f:
        trainers = json.load(f)

    filepath = os.path.join(app.config["OUTPUT_FOLDER"], "Summary_Report.pdf")
    generate_summary_pdf(trainers, filepath)

    return send_file(filepath, as_attachment=True, download_name="Invoice_Summary_Report.pdf")


# ── Utility filter ──
@app.template_filter("inr")
def inr_filter(value):
    try:
        return f"₹{float(value):,.2f}"
    except (ValueError, TypeError):
        return "₹0.00"


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
